import setuptools

setuptools.setup(
    name = "Tdrd",                                                                                                                              
    version = "0.0.1",
    author = "ditisrmel",
    license='MIT license',
    author_email="kimichen2907@gmail.com",
    description="Make a to-do record notebook",
    url="https://github.com/ditisrmel/Tdrn", 
    python_requires='>=3.11.4'
    

    
)
