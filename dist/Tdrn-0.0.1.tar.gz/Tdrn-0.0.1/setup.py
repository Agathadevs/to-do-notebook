import setuptools

setuptools.setup(
    name = "Tdrn",                                                                                                                              
    version = "0.0.1",
    author = "Cheng",
    license='MIT license',
    author_email="kimichen2907@gmail.com",
    description="Make a to-do record notebook",
    url="https://github.com/ditisrmel/Tdrn", 
    python_requires='>=3.11.4'
)
